"""
Application settings for the Intelligent Content Generation Accelerator.

Uses Pydantic settings management with environment variable configuration.
Includes brand guidelines as solution parameters for content strategy
and compliance validation.
"""

import json
import logging
import os
from typing import List, Optional

from pydantic import BaseModel, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing_extensions import Self

DOTENV_PATH = os.environ.get(
    "DOTENV_PATH", os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ".env")
)
MINIMUM_SUPPORTED_AZURE_OPENAI_PREVIEW_API_VERSION = "2025-01-01-preview"


def parse_comma_separated(value: str) -> List[str]:
    """Parse a comma-separated string into a list."""
    if isinstance(value, str) and len(value) > 0:
        return [item.strip() for item in value.split(",") if item.strip()]
    return []


class _UiSettings(BaseSettings):
    """UI configuration settings."""
    model_config = SettingsConfigDict(
        env_prefix="UI_", env_file=DOTENV_PATH, extra="ignore", env_ignore_empty=True
    )

    app_name: str = "Content Generation Accelerator"
    title: str = "Content Generation"
    logo: Optional[str] = None
    chat_logo: Optional[str] = None
    chat_title: str = "Marketing Content Generator"
    chat_description: str = "AI-powered multimodal content generation for marketing campaigns."
    favicon: str = "/favicon.ico"
    show_share_button: bool = False


class _ChatHistorySettings(BaseSettings):
    """CosmosDB chat history configuration."""
    model_config = SettingsConfigDict(
        env_prefix="AZURE_COSMOSDB_",
        env_file=DOTENV_PATH,
        extra="ignore",
        env_ignore_empty=True,
    )

    database: str
    account: str
    account_key: Optional[str] = None
    conversations_container: str
    products_container: str = "products"
    enable_feedback: bool = True


class _AzureOpenAISettings(BaseSettings):
    """Azure OpenAI configuration for GPT-5 and DALL-E 3."""
    model_config = SettingsConfigDict(
        env_prefix="AZURE_OPENAI_",
        env_file=DOTENV_PATH,
        extra="ignore",
        env_ignore_empty=True,
    )

    gpt_model: str = Field(default="gpt-5", alias="AZURE_OPENAI_GPT_MODEL")
    model: str = "gpt-5"
    dalle_model: str = Field(default="dall-e-3", alias="AZURE_OPENAI_DALLE_MODEL")
    dalle_endpoint: Optional[str] = Field(default=None, alias="AZURE_OPENAI_DALLE_ENDPOINT")
    resource: Optional[str] = None
    endpoint: Optional[str] = None
    temperature: float = 0.7
    top_p: float = 0.95
    max_tokens: int = 2000
    stream: bool = True
    api_version: str = "2024-06-01"
    preview_api_version: str = "2024-02-01"
    
    # Image generation settings
    image_size: str = "1024x1024"
    image_quality: str = "hd"

    @model_validator(mode="after")
    def ensure_endpoint(self) -> Self:
        if self.endpoint:
            return self
        elif self.resource:
            self.endpoint = f"https://{self.resource}.openai.azure.com"
            return self
        raise ValueError("AZURE_OPENAI_ENDPOINT or AZURE_OPENAI_RESOURCE is required")


class _AzureAISettings(BaseSettings):
    """Azure AI Foundry Agent settings."""
    model_config = SettingsConfigDict(
        env_prefix="AZURE_AI_",
        env_file=DOTENV_PATH,
        extra="ignore",
        env_ignore_empty=True,
    )
    agent_endpoint: Optional[str] = None
    agent_model_deployment_name: Optional[str] = None
    agent_api_version: Optional[str] = None


class _StorageSettings(BaseSettings):
    """Azure Blob Storage configuration."""
    model_config = SettingsConfigDict(
        env_prefix="AZURE_BLOB_",
        env_file=DOTENV_PATH,
        extra="ignore",
        env_ignore_empty=True,
    )

    account_name: str = Field(default="", alias="AZURE_BLOB_ACCOUNT_NAME")
    product_images_container: str = "product-images"
    generated_images_container: str = "generated-images"


class _CosmosSettings(BaseSettings):
    """Azure Cosmos DB configuration."""
    model_config = SettingsConfigDict(
        env_prefix="AZURE_COSMOS_",
        env_file=DOTENV_PATH,
        extra="ignore",
        env_ignore_empty=True,
    )

    endpoint: str = Field(default="", alias="AZURE_COSMOS_ENDPOINT")
    database_name: str = Field(default="content-generation", alias="AZURE_COSMOS_DATABASE_NAME")
    products_container: str = "products"
    conversations_container: str = "conversations"


class _SearchSettings(BaseSettings):
    """Azure AI Search configuration."""
    model_config = SettingsConfigDict(
        env_prefix="AZURE_AI_SEARCH_",
        env_file=DOTENV_PATH,
        extra="ignore",
        env_ignore_empty=True,
    )

    endpoint: str = Field(default="", alias="AZURE_AI_SEARCH_ENDPOINT")
    products_index: str = Field(default="products", alias="AZURE_AI_SEARCH_PRODUCTS_INDEX")
    images_index: str = Field(default="product-images", alias="AZURE_AI_SEARCH_IMAGE_INDEX")
    admin_key: Optional[str] = Field(default=None, alias="AZURE_AI_SEARCH_ADMIN_KEY")


class _BrandGuidelinesSettings(BaseSettings):
    """
    Brand guidelines stored as solution parameters.
    
    These are injected into all agent instructions for content strategy
    and compliance validation.
    """
    model_config = SettingsConfigDict(
        env_prefix="BRAND_",
        env_file=DOTENV_PATH,
        extra="ignore",
        env_ignore_empty=True,
    )

    # Voice and tone
    tone: str = "Professional yet approachable"
    voice: str = "Innovative, trustworthy, customer-focused"
    
    # Content restrictions (stored as comma-separated strings)
    prohibited_words_str: str = Field(default="", alias="BRAND_PROHIBITED_WORDS")
    required_disclosures_str: str = Field(default="", alias="BRAND_REQUIRED_DISCLOSURES")
    
    # Visual guidelines
    primary_color: str = "#0078D4"
    secondary_color: str = "#107C10"
    image_style: str = "Modern, clean, minimalist with bright lighting"
    typography: str = "Sans-serif, bold headlines, readable body text"
    
    # Compliance rules
    max_headline_length: int = 60
    max_body_length: int = 500
    require_cta: bool = True
    
    @property
    def prohibited_words(self) -> List[str]:
        """Parse prohibited words from comma-separated string."""
        return parse_comma_separated(self.prohibited_words_str)
    
    @property
    def required_disclosures(self) -> List[str]:
        """Parse required disclosures from comma-separated string."""
        return parse_comma_separated(self.required_disclosures_str)
    
    def get_compliance_prompt(self) -> str:
        """Generate compliance rules text for agent instructions."""
        return f"""
## Brand Compliance Rules

### Voice and Tone
- Tone: {self.tone}
- Voice: {self.voice}

### Content Restrictions
- Prohibited words: {', '.join(self.prohibited_words) if self.prohibited_words else 'None specified'}
- Required disclosures: {', '.join(self.required_disclosures) if self.required_disclosures else 'None required'}
- Maximum headline length: {self.max_headline_length} characters
- Maximum body length: {self.max_body_length} characters
- CTA required: {'Yes' if self.require_cta else 'No'}

### Visual Guidelines
- Primary brand color: {self.primary_color}
- Secondary brand color: {self.secondary_color}
- Image style: {self.image_style}
- Typography: {self.typography}

### Compliance Severity Levels
- ERROR: Legal/regulatory violations that MUST be fixed before content can be used
- WARNING: Brand guideline deviations that should be reviewed
- INFO: Style suggestions for improvement (optional)

When validating content, categorize each violation with the appropriate severity level.
"""

    def get_text_generation_prompt(self) -> str:
        """Generate brand guidelines for text content generation."""
        return f"""
## Brand Voice Guidelines

Write content that embodies these characteristics:
- Tone: {self.tone}
- Voice: {self.voice}

### Writing Rules
- Keep headlines under {self.max_headline_length} characters
- Keep body copy under {self.max_body_length} characters
- {'Always include a clear call-to-action' if self.require_cta else 'CTA is optional'}
- NEVER use these words: {', '.join(self.prohibited_words) if self.prohibited_words else 'No restrictions'}
- Include these disclosures when applicable: {', '.join(self.required_disclosures) if self.required_disclosures else 'None required'}
"""

    def get_image_generation_prompt(self) -> str:
        """Generate brand guidelines for image content generation."""
        return f"""
## Brand Visual Guidelines

Create images that follow these guidelines:
- Style: {self.image_style}
- Primary brand color to incorporate: {self.primary_color}
- Secondary accent color: {self.secondary_color}
- Professional, high-quality imagery suitable for marketing
- Bright, optimistic lighting
- Clean composition with 30% negative space
- No competitor products or logos
- Diverse representation if people are shown
"""


class _BaseSettings(BaseSettings):
    """Base application settings."""
    model_config = SettingsConfigDict(
        env_file=DOTENV_PATH,
        extra="ignore",
        arbitrary_types_allowed=True,
        env_ignore_empty=True,
    )
    auth_enabled: bool = False
    sanitize_answer: bool = False
    solution_name: Optional[str] = Field(default=None)
    azure_client_id: Optional[str] = Field(default=None, alias="AZURE_CLIENT_ID")


class _AppSettings(BaseModel):
    """Main application settings container."""
    base_settings: _BaseSettings = _BaseSettings()
    azure_openai: _AzureOpenAISettings = _AzureOpenAISettings()
    azure_ai: _AzureAISettings = _AzureAISettings()
    brand_guidelines: _BrandGuidelinesSettings = _BrandGuidelinesSettings()
    ui: Optional[_UiSettings] = _UiSettings()
    
    # Constructed properties
    chat_history: Optional[_ChatHistorySettings] = None
    blob: Optional[_StorageSettings] = None
    cosmos: Optional[_CosmosSettings] = None
    search: Optional[_SearchSettings] = None

    @model_validator(mode="after")
    def set_chat_history_settings(self) -> Self:
        try:
            self.chat_history = _ChatHistorySettings()
        except Exception:
            self.chat_history = None
        return self

    @model_validator(mode="after")
    def set_storage_settings(self) -> Self:
        try:
            self.blob = _StorageSettings()
        except Exception:
            self.blob = None
        return self

    @model_validator(mode="after")
    def set_cosmos_settings(self) -> Self:
        try:
            self.cosmos = _CosmosSettings()
        except Exception:
            self.cosmos = None
        return self

    @model_validator(mode="after")
    def set_search_settings(self) -> Self:
        try:
            self.search = _SearchSettings()
        except Exception:
            self.search = None
        return self


# Global settings instance
app_settings = _AppSettings()
