"""Agents package for Content Generation Solution Accelerator."""

from backend.agents.simple_agent import SimpleAgent

__all__ = [
    "SimpleAgent",
]
